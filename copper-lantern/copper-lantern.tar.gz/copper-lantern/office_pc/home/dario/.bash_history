ls
cd recipes
ls
cat stock_ratios.txt
cd ~
sudo passwd vince
cd /home/vince/Documents
ls -la
openssl enc -aes-256-cbc -pbkdf2 -salt -in ledger.csv -out ledger.enc
ls -la
shred -u ledger.csv
ls -la
cp ledger.enc /home/dario/ledger.enc
exit
