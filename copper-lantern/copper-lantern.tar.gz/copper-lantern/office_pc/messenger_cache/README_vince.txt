this is from the messenger app on the office pc. jamie says it
keeps a copy of chats from any account that logs in on it.
i don't understand half of it. - V
