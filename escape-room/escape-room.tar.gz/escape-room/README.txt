=== ESCAPE ROOM: EASY ===
You're locked in a small room. The flag looks like flag{...}
and it's split into pieces scattered around this directory.

Nothing here is what it seems at first glance.
Start by looking around... carefully.
